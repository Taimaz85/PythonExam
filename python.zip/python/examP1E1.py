file = open("mytext.txt", "r")
content = file.read()


print(content)

total_sum = 0

for line in content:
        try:
                
            number = int(line.strip())
            total_sum += number
        except ValueError:
            print(f"{line.strip()}")
    
print(f"The total sum of the numbers in the file is: {total_sum}")




