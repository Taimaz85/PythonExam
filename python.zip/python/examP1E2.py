class Zoo:
    def __init__(self):
        self.animals = []

    def add_animal(self):
        animal = input("Enter the name of the animal to add: ")
        self.animals.append(animal)
        print(f"{animal} has been added to the zoo.")

    def delete_animal(self):
        animal = input("Enter the name of the animal to delete: ")
        if animal in self.animals:
            self.animals.remove(animal)
            print(f"{animal} has been removed from the zoo.")
        else:
            print(f"{animal} is not in the zoo.")

    def list_animals(self):
        if not self.animals:
            print("The zoo has no animals.")
        else:
            print("The animals in the zoo are:")
            for animal in self.animals:
                print(animal)

    def modify_animal(self):
        old_animal = input("Enter the name of the animal to modify: ")
        if old_animal in self.animals:
            new_animal = input(f"Enter the new name for {old_animal}: ")
            index = self.animals.index(old_animal)
            self.animals[index] = new_animal
            print(f"{old_animal} has been renamed to {new_animal}.")
        else:
            print(f"{old_animal} is not in the zoo.")

def main():
    zoo = Zoo()

    while True:
        print("\nZoo Management System")
        print("1. Add a new animal to the zoo")
        print("2. Delete an animal from the zoo")
        print("3. List all the animals from the zoo")
        print("4. Exit the program")
        print("5. Modify an animal")
        choice = input("Enter your choice: ")

        if choice == '1':
            zoo.add_animal()
        elif choice == '2':
            zoo.delete_animal()
        elif choice == '3':
            zoo.list_animals()
        elif choice == '4':
            print("Exiting the program. Goodbye!")
            break
        elif choice == '5':
            zoo.modify_animal()
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
