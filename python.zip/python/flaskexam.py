from flask import Flask, jsonify, abort

app = Flask(__name__)

# A. Create virtual environment
# B. Activate the virtual environment
# C. Install flask with pip
# D. Run the flask server

# 1. Make the default endpoint (/) return an <h1> saying "Programming languages"
# 2. Make an endpoint (/languages) that returns all programming languages (programming_languages array) in json format
# 3. Make an endpoint (/languages/ID) where ID is an integer url parameter, and the endpoint returns the 
#       language with the matching ID, or aborts with a 404 error and a text "Programming language not found" 

programming_languages = [
    {
        'id': 1,
        'name': 'Python',
        'description': 'A high-level, interpreted programming language known for its readability and versatility.',
    },
    {
        'id': 2,
        'name': 'JavaScript',
        'description': 'A scripting language primarily used for web development to create interactive effects within web browsers.',
    },
    {
        'id': 3,
        'name': 'Java',
        'description': 'A widely-used programming language known for its portability, performance, and security features.',
    },
    {
        'id': 4,
        'name': 'C++',
        'description': 'A powerful general-purpose programming language often used in systems software, game development, and other performance-critical applications.',
    },
    {
        'id': 5,
        'name': 'Go',
        'description': 'A statically typed, compiled programming language designed for building simple, reliable, and efficient software.',
    }
]

from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello_world():
    return '<h1>Programming languages</h1>'

@app.route('/languages')
def get_languages():
    return jsonify(programming_languages)

@app.route('/languages/<int:id>')
def get_languagess(id):
    language = next((lang for lang in programming_languages if lang['id'] == id), None)
    if language is None:
        abort(404, description = 'Programming language is not found')
    return jsonify(language)

if __name__ == '__main__':
    app.run(debug=True)



if __name__ == '__main__':
    app.run()